﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Conversione_decimale_binario
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Dato un numero in base 10 nel range 0 - 255 convertirlo in base 2. 

            int num, bin, i = 0;
            int[] binario;
            binario = new int[256];

            do
            {
                Console.WriteLine("Inserire un numero in base 10 nel range 0 - 255:");
                num = Convert.ToInt32(Console.ReadLine());
                if (num < 0 || num > 255)
                {
                    Console.WriteLine("Out of range");
                    Console.ReadLine();
                }
            } while (num < 0 || num > 255);

            do
            {
                if (num % 2 == 0)
                {
                    binario[i] = 0;
                    num = num / 2;
                }
                else
                {
                    binario[i] = 1;
                    num = (num - 1) / 2;
                }

                i = i + 1;
            } while (num >= 1);

            for (int t = 0; t < 8 - i; t++)
            {
                Console.Write(0);
            }

            for (i = i - 1; i >= 0; i--)
            {
                Console.Write(binario[i]);
            }

            Console.ReadLine();
        }
    }
}