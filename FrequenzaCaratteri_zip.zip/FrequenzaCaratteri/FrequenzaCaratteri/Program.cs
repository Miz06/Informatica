﻿using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FrequenzaCaratteri
{
    internal class Program
    {
        static void Main(string[] args)
        { //Alessandro Mizzon 
            char car;
            int numeri = 0, altro = 0;
            char[] alfabeto = new char[26];
            int[] frequenza = new int[26];

            for (int i = 0; i < 26; i++) 
            {
                frequenza[i] = 0;
            }

            for (int i = 0; i<26; i++) 
            {
                alfabeto[i] = Convert.ToChar(65 + i); // Assegno ad ogni sezione dell'array "alfabeto" un codice asci (convertito in caratere) partendo da 65 (che equivale ad A) ed aggiungengo 1 fino ad arrivare a 90 (che è uguale a Z)
            }

            Console.WriteLine("Inserire una frase:");
            
            do
            {
                car = Convert.ToChar(Console.Read());

                for (int i = 0; i < 26; i++)
                {
                    if (alfabeto[i] == car) // Se il carattere inserito corrisponde ad una lettera dell'array "alfabeto" allora la frequenza di quella lettera viene incrementata di 1
                    {
                        frequenza[i]++; 
                    }
                }

                if (car>=48 && car<=57)
                {
                    numeri++; 
                }
                else if(car >= 33 && car <= 47 || car >= 58 && car <= 64 || car >= 91 && car <= 96 || car >= 123 && car <= 126)
                {
                    altro++; 
                }

            } while (car != 13);

            Console.WriteLine($"I numeri all'interno della frase sono {numeri} e i caratteri che non sono ne lettere ne numeri sono {altro}");

            Console.WriteLine("La frequenza di lettere presenti nella frase è:"); 
            for (int i = 0; i<26; i++)
            {
                if (frequenza[i] != 0) //Stampo a video solamente la frequenza delle lettere presenti nella frase 
                {
                    Console.WriteLine($"{alfabeto[i]}: {frequenza[i]}"); 
                }
            }
            
            Console.ReadLine();
            Console.ReadLine(); 
        }
    }
}
