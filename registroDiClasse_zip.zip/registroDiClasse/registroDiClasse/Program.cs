﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace laScuolaElementare
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int N, num, spazio = 0;

            Console.WriteLine("Inserire il numero di studenti della classe:");
            N = Convert.ToInt32(Console.ReadLine());

            string[] classe = new string[N];

            do
            {
                Console.WriteLine("===Registro di classe===");
                Console.WriteLine("[1] inserimento");
                Console.WriteLine("[2] presenti");
                Console.WriteLine("[3] ricerca");
                Console.WriteLine("[4] ricerca posizione alunno/registro");
                Console.WriteLine("[5] esci");

                do
                {
                    Console.WriteLine("Inserire il numero corrispondente alla sezione di registro a cui si vuole andare:");
                    num = Convert.ToInt32(Console.ReadLine());
                } while (num < 1 || num > 5);

                Console.Clear();

                switch (num)
                {
                    case (1):
                        if (spazio < N)
                        {
                            Console.WriteLine("Inserire il nome del bambino:");
                            classe[spazio] = Console.ReadLine();
                            spazio++;
                        }
                        else
                        { 
                            Console.WriteLine("Non c'è più posto nella classe"); 
                        }
                        Console.WriteLine("Premere invio per tornare al menù principale");
                        break;

                    case (2):
                        Console.WriteLine("GLi studenti della classe sono:");
                        for (int i = 0; i < spazio; i++)
                        {
                            Console.WriteLine($"{i+1}) {classe[i]}"); 
                        }
                        Console.WriteLine("Premere invio per tornare al menù principale");
                        break;

                    case (3):
                        Console.WriteLine("Funzionalità non ancora implementata");
                        Console.WriteLine("Premere invio per tornare al menù principale");
                        break;

                    case (4):
                        Console.WriteLine("Funzionalità non ancora implementata");
                        Console.WriteLine("Premere invio per tornare al menù principale");
                        break;

                    case (5):
                        Console.WriteLine("Programma terminato");
                        break;
                }
                Console.ReadLine();
                Console.Clear();
            } while (num!=5); 
        }
    }
}