﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ereditarietacostruttori
{
    internal class Elettrodomestico:Oggetto
    {
        protected double prezzo;
        public Elettrodomestico(double prezzo, int peso):base(peso) 
        {
            this.prezzo = prezzo;
            
        }

        public void MetodoElettrodomestico()
        {
            Console.WriteLine($"Sono un elettrodomestico, il mio prezzo è {prezzo}");
        }
       // public double Prezzo { get { return prezzo; } set { prezzo = value; } }
    }
}
