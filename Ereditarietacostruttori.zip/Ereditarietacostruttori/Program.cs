﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ereditarietacostruttori
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Oggetto oggetto = new Oggetto(50);
            //Elettrodomestico elettrodomestico = new Elettrodomestico(34.0, 50);
            //elettrodomestico.MetodoElettrodomestico();
            //elettrodomestico.MetodoOggetto();
            Lavatrice lavatrice = new Lavatrice(20,45.5,82);
           
            lavatrice.MetodoOggetto();
            lavatrice.MetodoElettrodomestico();
            lavatrice.MetodoLavatrice();
            Console.ReadLine();
        }
    }
}
