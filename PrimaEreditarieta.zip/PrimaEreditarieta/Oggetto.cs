﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrimaEreditarieta
{
    internal class Oggetto
    {
        int peso;
        public void MetodoOggetto()
        {
            Console.WriteLine($"Sono un oggetto, il mio peso è {peso}");
        }
        public int Peso {  get { return peso; } set {  peso = value; } }
    }
}
