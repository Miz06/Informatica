﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrimaEreditarieta
{
    internal class Lavatrice:Elettrodomestico
    {
        int numeroGiri;
        public void MetodoLavatrice()
        {
            Console.WriteLine($"Sono una lavatrice, il mio numero di giri è {numeroGiri}");
        }
        //public int NumeroGiri {  get { return numeroGiri; } set { numeroGiri = value; } }
        public void CambiaPrezzo()
        {
            prezzo++;
        }
    }
}
