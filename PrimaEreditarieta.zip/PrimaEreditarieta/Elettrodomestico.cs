﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrimaEreditarieta
{
    internal class Elettrodomestico:Oggetto
    {
        protected double prezzo;
        public void MetodoElettrodomestico()
        {
            Console.WriteLine($"Sono un elettrodomestico, il mio prezzo è {prezzo}");
        }
       // public double Prezzo { get { return prezzo; } set { prezzo = value; } }
    }
}
