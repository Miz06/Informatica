﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrimaEreditarieta
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //QUESTO ESEMPIO E' VOLUTAMENTE SENZA COSTRUTTORI PERCHE' HA UNO SCOPO DIDATTICO.
            //E' UN BRUTTO STILE DI PROGRAMMAZIONE PERCH' VANNO USATI I COSTRUTTORI PER L'INIZIALIZZAZIONE DEI COSTRUTTORI.
            //Elettrodomestico elet1 = new Elettrodomestico();
            //elet1.Prezzo=10.5;
            //elet1.MetodoElettrodomestico();
            //Console.ReadLine();
            
            Lavatrice lavatrice1 = new Lavatrice();
            //lavatrice1.NumeroGiri = 20;
            //lavatrice1.Prezzo = 10.5;
            lavatrice1.MetodoElettrodomestico();
            lavatrice1.MetodoLavatrice();
            lavatrice1.Peso = 50;
            lavatrice1.MetodoOggetto();
            Console.ReadLine();
        }
    }
}
