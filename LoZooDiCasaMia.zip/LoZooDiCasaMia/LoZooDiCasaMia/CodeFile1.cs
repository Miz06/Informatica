﻿namespace LoZooDiCasaMia
{
    enum mangiato
    { 
        deveMangiare,
        haMangiato,
        nonPuòMangiare,
    }
}