﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpaziBianchi
{
    internal class Program
    {
        static void Main(string[] args)
        {//Alessandro Mizzon
            const string Frase = "La       mamma va      al mercato    a comprare le albicocche.";
            string parola = "", fraseCorretta = "";
            bool spazio = false;

            for (int i = 0; i < Frase.Length; i++)
            {
                if (Frase[i] == ' ')
                {
                    fraseCorretta += parola;
                    parola = "";
                    spazio = true;
                }
                else
                {
                    if (spazio)
                    {
                        fraseCorretta += " ";
                    }
                    spazio = false;
                    parola += Frase[i];

                    if (Frase[i] == '.')
                    {
                        fraseCorretta += parola;
                    }
                }
            }

            Console.WriteLine(fraseCorretta);

            Console.ReadLine();
        }
    }
}
